function [Q R]=GramSchmidtModified_MIT(Y)
%[Q R]=mdgs(Y)
%
%Takes the matrix Y whose columns are the bases you wish to orthonormalise.
%
%Q is the orthonormalisation (column vectors are the orthonormal basis)
%and R are the coefficients.
%Lecture 5
% 
% Gram-Schmidt Orthogonalization
% 
% MIT 18.335J / 6.337J
% 
% Introduction to Numerical Methods
% 
% Per-Olof Persson
% 
% September 21, 2006


[nr,nc]=size(Y);

for j=1:nc
    uj=Y(:,j);
    for i=1:j-1
        if 0 %Classical Gram Schmidt
        alpha(i,j)=InnerProd(Q(:,i),Y(:,i));
        else % Modified Gram Schmidt
            alpha(i,j)=InnerProd(Q(:,i),uj);            
        end
    uj=uj-alpha(i,j)*Q(:,i);
    end
    alpha(j,j)=sqrt(InnerProd(uj,uj));
    Q(:,j)=uj/alpha(j,j);
end

%% Representation
R=zeros(nc,nc);
for i = 1:nc
    for j = 1:i
        R(j,i)=InnerProd(Q(:,j),Y(:,i));
    end
end
%R=Q'*Y;
%%

    function z=proj(x,y)
        %
        %  Assume x^Tx  = 1.
        %
        z=InnerProd(x,y)*x;
        %z=(InnerProd(x,y)/InnerProd(x,x))*x;
    end
    function ip = InnerProd(x,y)
        % Inner Product of vectors in R^n
        %
        ip=sum(x.*y);
    end

end

