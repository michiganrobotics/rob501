
disp('You can change epsilon at the top of the file. It is denoted by the variable a.')
a=1e-8
%a=0.1
y1=[1 a 0 0]';
y2=[1 0 a 0]';
y3=[1 0 0 a]';

e1=[1 0 0 0]';
e2=[0 1 0 0]';
e3=[0 0 1 0]';
e4=[0 0 0 1]';

Y=[y1 y2 y3];

%Y=rand(4,4);

[Q1,R1]=GramSchmidtClassic(Y),  % Q1'*Q1-eye(3), 

[Q2, R2] = GramSchmidtClassic([y1,-e2+e3,-e3+e4]),    %Q2'*Q2-eye(3)

ErrorInComputingOrthonomalBasis_ClassicGS = norm(Q1-Q2)

disp('Hit any key')
pause


[Q3,R3]=GramSchmidtModified(Y),   %Q3'*Q3-eye(3), 

[Q4,R4] = GramSchmidtModified([y1,-e2+e3,-e3+e4]),    %Q4'*Q4-eye(3)

ErrorInComputingOrthonomalBasis_ModifiedGS=norm(Q3-Q4)



    